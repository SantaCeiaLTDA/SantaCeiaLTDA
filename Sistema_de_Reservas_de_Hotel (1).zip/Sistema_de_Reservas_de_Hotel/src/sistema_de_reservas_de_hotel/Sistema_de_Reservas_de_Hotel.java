/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema_de_reservas_de_hotel;
import interfaces.Login;
/**
 *
 * @author gpontes
 */
public class Sistema_de_Reservas_de_Hotel {

    /** 
     * @param args the command line arguments
     */
    public static void main(String[] args) {    
        // TODO code application logic here
      Login f = new Login();
       f.setVisible(true);     
          
        /*
        1º Tela de Login; Confere; Espaço para modificações visuais.
        2º Calendário de Reservas;Confere.
        3º Alterações nas Reservas; Confere. 
        4º Registro de Atividades e Relatórios;
        5º Visualização de Informações dos Hóspedes
        6º Check-in e Check-out Offline;
        7º Etc.
        */
        
        
    }
    
}
